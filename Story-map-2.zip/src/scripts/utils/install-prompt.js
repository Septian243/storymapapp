window.addEventListener('beforeinstallprompt', (event) => {
    console.log('🧩 PWA install prompt ditangani secara silent. Pengguna tetap bisa install via menu browser.');
});
